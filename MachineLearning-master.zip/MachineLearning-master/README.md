## GeneralUtil ： tells about how to build general machine learning model
> SVM.java : svm classification model
>> class SVM
>>> method: trainModel() --- use training set to build svm model 
</br> method: predictData() --- predict new data by trained svm model

> GBDT.java: GBDT regression model
>> class GBDT
>>> method: trainModel() --- use training set to build GBDT model 
</br> method: predict() --- predict new data by trained GBDT model
